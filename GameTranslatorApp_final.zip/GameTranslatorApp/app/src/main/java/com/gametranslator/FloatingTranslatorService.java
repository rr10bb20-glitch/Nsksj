package com.gametranslator;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/**
 * FloatingTranslatorService — v3 مع قائمة اختيار اللغة
 * ────────────────────────────────────────────────────────
 * ✅ ضغط الزر → قائمة اختيار لغة المصدر والهدف
 * ✅ بعد الاختيار → يترجم مباشرة
 * ✅ اللوحة شفافة ولا تحجب اللمس
 * ✅ تختفي تلقائياً بعد 6 ثوانٍ
 * ✅ ضغط طويل = إيقاف الخدمة
 */
public class FloatingTranslatorService extends Service {

    private static final String CHANNEL_ID      = "translator_channel";
    private static final int    NOTIF_ID        = 42;
    private static final long   AUTO_DISMISS_MS = 6_000;

    // اللغات المتاحة: [كود، اسم عربي، علم]
    private static final String[][] LANGUAGES = {
        {"auto", "تلقائي",    "🔍"},
        {"ar",   "العربية",   "🇸🇦"},
        {"en",   "الإنجليزية","🇺🇸"},
        {"ja",   "اليابانية", "🇯🇵"},
        {"ko",   "الكورية",   "🇰🇷"},
        {"zh",   "الصينية",   "🇨🇳"},
        {"fr",   "الفرنسية",  "🇫🇷"},
        {"de",   "الألمانية", "🇩🇪"},
        {"es",   "الإسبانية", "🇪🇸"},
        {"ru",   "الروسية",   "🇷🇺"},
        {"tr",   "التركية",   "🇹🇷"},
    };

    private WindowManager windowManager;
    private View          floatBtn;
    private View          resultPanel;
    private View          langPickerPanel;
    private WindowManager.LayoutParams btnParams;
    private WindowManager.LayoutParams panelParams;
    private WindowManager.LayoutParams pickerParams;

    private boolean isPanelVisible  = false;
    private boolean isPickerVisible = false;

    // مرحلة الاختيار: 1 = اختيار لغة المصدر، 2 = اختيار لغة الهدف
    private int    pickerStep   = 1;
    private String selectedFrom = "en";

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private Runnable autoDismissRunnable;

    private int screenW, screenH;

    private static final float BTN_ALPHA_IDLE   = 0.30f;
    private static final float BTN_ALPHA_ACTIVE = 0.90f;

    // ────────────────────────────────────────────
    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        DisplayMetrics dm = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(dm);
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;

        createNotificationChannel();
        startForeground(NOTIF_ID, buildNotification());
        buildFloatingButton();
    }

    // ────────────────────────────────────────────
    //  بناء الزر العائم
    // ────────────────────────────────────────────
    private void buildFloatingButton() {
        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        floatBtn = LayoutInflater.from(this).inflate(R.layout.floating_button, null);

        btnParams = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
              | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        );
        btnParams.gravity = Gravity.TOP | Gravity.START;
        btnParams.x = screenW - 160;
        btnParams.y = screenH / 2;

        floatBtn.setAlpha(BTN_ALPHA_IDLE);
        floatBtn.setOnTouchListener(new DragTouchListener());
        windowManager.addView(floatBtn, btnParams);
    }

    // ────────────────────────────────────────────
    //  قائمة اختيار اللغة — الخطوة 1 (لغة المصدر)
    // ────────────────────────────────────────────
    private void showFromLangPicker() {
        removePicker();
        removePanel();
        cancelAutoDismiss();
        setButtonAlpha(BTN_ALPHA_ACTIVE);

        pickerStep = 1;
        langPickerPanel = buildLangPicker(
            "من أي لغة؟",
            true,   // اعرض "تلقائي"
            (code) -> {
                selectedFrom = code;
                // انتقل لخطوة اختيار لغة الهدف
                mainHandler.post(this::showToLangPicker);
            }
        );
        addPickerToWindow(langPickerPanel);
        isPickerVisible = true;
    }

    // ────────────────────────────────────────────
    //  قائمة اختيار اللغة — الخطوة 2 (لغة الهدف)
    // ────────────────────────────────────────────
    private void showToLangPicker() {
        removePicker();
        pickerStep = 2;
        langPickerPanel = buildLangPicker(
            "إلى أي لغة؟",
            false,  // لغة الهدف لا تكون "تلقائي"
            (code) -> {
                removePicker();
                isPickerVisible = false;
                // احفظ الإعداد وابدأ الترجمة
                ClipboardBridge.saveLang(FloatingTranslatorService.this, selectedFrom, code);
                startTranslation(selectedFrom, code);
            }
        );
        addPickerToWindow(langPickerPanel);
        isPickerVisible = true;
    }

    // ────────────────────────────────────────────
    //  بناء View القائمة
    // ────────────────────────────────────────────
    interface LangCallback { void onPick(String code); }

    private View buildLangPicker(String title, boolean includeAuto, LangCallback callback) {
        // حاوية خارجية
        FrameLayout root = new FrameLayout(this);
        root.setPadding(8, 8, 8, 8);

        // البطاقة الرئيسية
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(24, 18, 24, 14);
        card.setBackgroundResource(R.drawable.result_card_bg);

        // العنوان + زر إغلاق
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView titleTv = new TextView(this);
        titleTv.setText(title);
        titleTv.setTextColor(Color.parseColor("#8ab4f8"));
        titleTv.setTextSize(14f);
        titleTv.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams titleLp =
            new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        card.addView(titleTv, titleLp);   // مؤقتاً خارج الصف
        card.addView(titleRow);

        // فاصل
        View div = new View(this);
        LinearLayout.LayoutParams divLp =
            new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1);
        divLp.setMargins(0, 10, 0, 10);
        div.setBackgroundColor(Color.parseColor("#1e3060"));
        card.addView(div, divLp);

        // زر إغلاق القائمة
        TextView closeBtn = new TextView(this);
        closeBtn.setText("✕");
        closeBtn.setTextColor(Color.parseColor("#e03850"));
        closeBtn.setTextSize(16f);
        closeBtn.setPadding(0, 0, 4, 0);
        closeBtn.setOnClickListener(v -> {
            removePicker();
            isPickerVisible = false;
            setButtonAlpha(BTN_ALPHA_IDLE);
            setButtonText("⚡");
        });

        // عنوان + X في صف واحد
        card.removeView(titleTv);
        titleRow.addView(titleTv, titleLp);
        titleRow.addView(closeBtn);

        // Scroll لو اللغات كثيرة
        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout langList = new LinearLayout(this);
        langList.setOrientation(LinearLayout.VERTICAL);

        for (String[] lang : LANGUAGES) {
            String code = lang[0];
            String name = lang[1];
            String flag = lang[2];

            // تخطّ "تلقائي" في لغة الهدف
            if (!includeAuto && code.equals("auto")) continue;
            // لا تعرض نفس لغة المصدر كهدف
            if (!includeAuto && code.equals(selectedFrom)) continue;

            TextView row = new TextView(this);
            row.setText(flag + "  " + name);
            row.setTextColor(Color.parseColor("#c0d4f8"));
            row.setTextSize(15f);
            row.setPadding(8, 18, 8, 18);
            row.setClickable(true);
            row.setFocusable(true);

            row.setOnClickListener(v -> callback.onPick(code));

            // تمييز بسيط عند اللمس
            row.setOnTouchListener((v, ev) -> {
                if (ev.getAction() == MotionEvent.ACTION_DOWN) {
                    row.setTextColor(Color.parseColor("#5a8aff"));
                } else if (ev.getAction() == MotionEvent.ACTION_UP
                        || ev.getAction() == MotionEvent.ACTION_CANCEL) {
                    row.setTextColor(Color.parseColor("#c0d4f8"));
                }
                return false;
            });

            // فاصل خفيف بين الصفوف
            langList.addView(row);
            View rowDiv = new View(this);
            LinearLayout.LayoutParams rdLp =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1);
            rowDiv.setBackgroundColor(Color.parseColor("#0e1e40"));
            langList.addView(rowDiv, rdLp);
        }

        scroll.addView(langList);

        // حدد ارتفاع أقصى = 55% من الشاشة
        int maxH = (int)(screenH * 0.55f);
        ScrollView.LayoutParams scrollLp =
            new ScrollView.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, maxH);
        card.addView(scroll, scrollLp);
        root.addView(card);
        return root;
    }

    private void addPickerToWindow(View picker) {
        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        pickerParams = new WindowManager.LayoutParams(
            (int)(screenW * 0.75f),
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            // القائمة تستقبل اللمس (بخلاف لوحة النتيجة)
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );
        pickerParams.gravity = Gravity.CENTER;
        windowManager.addView(picker, pickerParams);
    }

    private void removePicker() {
        if (langPickerPanel != null) {
            try { windowManager.removeView(langPickerPanel); } catch (Exception ignored) {}
            langPickerPanel = null;
        }
        isPickerVisible = false;
    }

    // ────────────────────────────────────────────
    //  الترجمة الفعلية
    // ────────────────────────────────────────────
    private void startTranslation(String fromLang, String toLang) {
        showLoadingPanel();
        setButtonText("⏳");

        new Thread(() -> {
            try {
                String text = getClipboardText();
                if (text == null || text.isEmpty()) {
                    showError("الحافظة فارغة — انسخ نصاً من اللعبة ثم اضغط الزر");
                    return;
                }
                String translated = translateText(text, fromLang, toLang);
                mainHandler.post(() -> {
                    showResultPanel(text, translated, toLang);
                    setButtonAlpha(BTN_ALPHA_IDLE);
                    setButtonText("⚡");
                    scheduleAutoDismiss();
                });
            } catch (Exception e) {
                showError("خطأ: " + e.getMessage());
            }
        }).start();
    }

    // ────────────────────────────────────────────
    //  لوحة النتيجة
    // ────────────────────────────────────────────
    private void removePanel() {
        if (resultPanel != null) {
            try { windowManager.removeView(resultPanel); } catch (Exception ignored) {}
            resultPanel = null;
        }
        isPanelVisible = false;
    }

    private void showLoadingPanel() {
        mainHandler.post(() -> {
            removePanel();
            addPanelToWindow(buildResultView("", "", "", true));
        });
    }

    private void showResultPanel(String orig, String trans, String toLang) {
        removePanel();
        addPanelToWindow(buildResultView(orig, trans, toLang, false));
        isPanelVisible = true;
    }

    private void addPanelToWindow(View panel) {
        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        resultPanel = panel;
        panelParams = new WindowManager.LayoutParams(
            (int)(screenW * 0.82f),
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
              | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
              | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        );
        panelParams.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        panelParams.y = 48;

        windowManager.addView(resultPanel, panelParams);
        isPanelVisible = true;
    }

    // ────────────────────────────────────────────
    //  بناء View النتيجة
    // ────────────────────────────────────────────
    private static String getLangName(String code) {
        for (String[] l : new String[][]{
            {"auto","تلقائي","🔍"},{"ar","العربية","🇸🇦"},{"en","الإنجليزية","🇺🇸"},
            {"ja","اليابانية","🇯🇵"},{"ko","الكورية","🇰🇷"},{"zh","الصينية","🇨🇳"},
            {"fr","الفرنسية","🇫🇷"},{"de","الألمانية","🇩🇪"},{"es","الإسبانية","🇪🇸"},
            {"ru","الروسية","🇷🇺"},{"tr","التركية","🇹🇷"}})
            if (l[0].equals(code)) return l[2] + " " + l[1];
        return code;
    }

    private View buildResultView(String original, String translated, String toLang, boolean loading) {
        FrameLayout container = new FrameLayout(this);
        container.setPadding(6, 6, 6, 6);
        container.setAlpha(0.88f);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(28, 18, 28, 16);
        card.setBackgroundResource(R.drawable.result_card_bg);

        if (loading) {
            TextView tv = new TextView(this);
            tv.setText("⏳  جاري الترجمة…");
            tv.setTextColor(Color.parseColor("#8ab4f8"));
            tv.setTextSize(13f);
            tv.setTypeface(Typeface.DEFAULT_BOLD);
            card.addView(tv);
        } else {
            addLabel(card, "النص الأصلي", "#4a6a9a");
            TextView origTv = new TextView(this);
            origTv.setText(original.length() > 100 ? original.substring(0, 100) + "…" : original);
            origTv.setTextColor(Color.parseColor("#7a9acd"));
            origTv.setTextSize(12f);
            origTv.setPadding(0, 4, 0, 10);
            card.addView(origTv);

            View div = new View(this);
            LinearLayout.LayoutParams dp =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1);
            div.setBackgroundColor(Color.parseColor("#1e3060"));
            card.addView(div, dp);

            addLabel(card, "الترجمة — " + getLangName(toLang), "#5a8aff");
            TextView transTv = new TextView(this);
            transTv.setText(translated);
            transTv.setTextColor(Color.parseColor("#e8f0ff"));
            transTv.setTextSize(19f);
            transTv.setTypeface(Typeface.DEFAULT_BOLD);
            transTv.setLineSpacing(4f, 1.2f);
            transTv.setPadding(0, 8, 0, 0);
            card.addView(transTv);

            TextView hint = new TextView(this);
            hint.setText("⏱ تختفي بعد 6 ثوانٍ  •  اضغط ⚡ للإغلاق");
            hint.setTextColor(Color.parseColor("#3a5580"));
            hint.setTextSize(9f);
            hint.setPadding(0, 10, 0, 0);
            card.addView(hint);
        }

        container.addView(card);
        return container;
    }

    private void addLabel(LinearLayout parent, String text, String colorHex) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor(colorHex));
        tv.setTextSize(9f);
        tv.setAllCaps(true);
        tv.setLetterSpacing(0.12f);
        tv.setPadding(0, 10, 0, 4);
        parent.addView(tv);
    }

    // ────────────────────────────────────────────
    //  إخفاء لوحة النتيجة
    // ────────────────────────────────────────────
    private void hideResultPanel() {
        cancelAutoDismiss();
        mainHandler.post(() -> {
            removePanel();
            setButtonAlpha(BTN_ALPHA_IDLE);
            setButtonText("⚡");
        });
    }

    private void scheduleAutoDismiss() {
        autoDismissRunnable = this::hideResultPanel;
        mainHandler.postDelayed(autoDismissRunnable, AUTO_DISMISS_MS);
    }

    private void cancelAutoDismiss() {
        if (autoDismissRunnable != null) {
            mainHandler.removeCallbacks(autoDismissRunnable);
            autoDismissRunnable = null;
        }
    }

    private void showError(String msg) {
        mainHandler.post(() -> {
            hideResultPanel();
            removePicker();
            setButtonAlpha(BTN_ALPHA_IDLE);
            setButtonText("⚡");
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        });
    }

    // ────────────────────────────────────────────
    //  مساعدات الزر
    // ────────────────────────────────────────────
    private void setButtonText(String txt) {
        if (floatBtn == null) return;
        TextView tv = floatBtn.findViewById(R.id.btnText);
        if (tv != null) tv.setText(txt);
    }

    private void setButtonAlpha(float alpha) {
        if (floatBtn != null) floatBtn.setAlpha(alpha);
    }

    // ────────────────────────────────────────────
    //  Clipboard
    // ────────────────────────────────────────────
    private String getClipboardText() {
        try {
            android.content.ClipboardManager cm =
                (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null && cm.hasPrimaryClip()) {
                android.content.ClipData.Item item = cm.getPrimaryClip().getItemAt(0);
                CharSequence t = item.getText();
                if (t != null) return t.toString().trim();
            }
        } catch (Exception ignored) {}
        return null;
    }

    // ────────────────────────────────────────────
    //  Google Translate (غير رسمي — بدون API Key)
    //  نفس الـ endpoint اللي يستخدمه translate.google.com
    // ────────────────────────────────────────────
    private String translateText(String text, String fromLang, String toLang) throws Exception {
        if (text.length() > 500) text = text.substring(0, 500);
        String from    = fromLang.equals("auto") ? "auto" : fromLang;
        String encoded = URLEncoder.encode(text, "UTF-8");
        String urlStr  = "https://translate.googleapis.com/translate_a/single"
            + "?client=gtx"
            + "&sl=" + from
            + "&tl=" + toLang
            + "&dt=t"
            + "&q=" + encoded;

        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("User-Agent", "Mozilla/5.0");
        conn.setConnectTimeout(8000);
        conn.setReadTimeout(8000);

        BufferedReader reader = new BufferedReader(
            new InputStreamReader(conn.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();

        // الرد: [[[" مترجم","أصلي",...],...],...,...]
        // نجمع كل أجزاء الترجمة من العنصر الأول
        org.json.JSONArray root  = new org.json.JSONArray(sb.toString());
        org.json.JSONArray parts = root.getJSONArray(0);
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < parts.length(); i++) {
            org.json.JSONArray part = parts.getJSONArray(i);
            if (!part.isNull(0)) result.append(part.getString(0));
        }
        String translated = result.toString().trim();
        if (translated.isEmpty()) throw new Exception("ترجمة فارغة");
        return translated;
    }

    // ────────────────────────────────────────────
    //  Drag + ضغط قصير / طويل
    // ────────────────────────────────────────────
    private class DragTouchListener implements View.OnTouchListener {
        private int   initX, initY;
        private float touchX, touchY;
        private boolean isDragging = false;
        private long    downTime;
        private static final long LONG_PRESS_MS = 800;

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    initX  = btnParams.x;
                    initY  = btnParams.y;
                    touchX = e.getRawX();
                    touchY = e.getRawY();
                    isDragging = false;
                    downTime   = System.currentTimeMillis();
                    setButtonAlpha(BTN_ALPHA_ACTIVE);
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float dx = e.getRawX() - touchX;
                    float dy = e.getRawY() - touchY;
                    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) {
                        isDragging = true;
                        btnParams.x = Math.max(0, Math.min(initX + (int)dx, screenW - 120));
                        btnParams.y = Math.max(0, Math.min(initY + (int)dy, screenH - 120));
                        windowManager.updateViewLayout(floatBtn, btnParams);
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                    long elapsed = System.currentTimeMillis() - downTime;
                    if (!isDragging) {
                        if (elapsed >= LONG_PRESS_MS) {
                            // ضغط طويل → إيقاف الخدمة
                            Toast.makeText(FloatingTranslatorService.this,
                                "تم إيقاف مترجم الألعاب ✓", Toast.LENGTH_SHORT).show();
                            stopSelf();
                        } else {
                            // ضغط قصير
                            if (isPanelVisible) {
                                hideResultPanel();
                            } else if (isPickerVisible) {
                                removePicker();
                                setButtonAlpha(BTN_ALPHA_IDLE);
                            } else {
                                // افتح قائمة اختيار اللغة دائماً
                                showFromLangPicker();
                            }
                        }
                    } else {
                        setButtonAlpha(BTN_ALPHA_IDLE);
                    }
                    return true;
            }
            return false;
        }
    }

    // ────────────────────────────────────────────
    //  Notification
    // ────────────────────────────────────────────
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "مترجم الألعاب", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("خدمة الترجمة العائمة");
            ch.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotification() {
        PendingIntent pi = PendingIntent.getActivity(
            this, 0,
            new Intent(this, MainActivity.class),
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                ? PendingIntent.FLAG_IMMUTABLE : 0
        );
        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("⚡ مترجم الألعاب يعمل")
            .setContentText("اضغط الزر ← اختر اللغة ← الترجمة فوراً  •  ضغط طويل لإيقاف")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();
    }

    // ────────────────────────────────────────────
    //  Lifecycle
    // ────────────────────────────────────────────
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        cancelAutoDismiss();
        removePicker();
        if (floatBtn    != null) try { windowManager.removeView(floatBtn);    } catch (Exception ignored) {}
        if (resultPanel != null) try { windowManager.removeView(resultPanel); } catch (Exception ignored) {}
    }
}
